# Ambattur Skill Mission — website

Static site for the Ambattur constituency skill-training programme. Bilingual
(Tamil primary, English secondary). Plain HTML and CSS — no build step, no
framework, no dependencies. Every page works by opening the file directly.

## Pages

| File | Page |
| --- | --- |
| `index.html` | முகப்பு · Home |
| `skill-mission.html` | திறன் இயக்கம் · The Skill Mission |
| `programmes.html` | திட்டங்கள் · Programmes |
| `apply.html` | விண்ணப்பியுங்கள் · Apply |
| `balamurugan.html` | திரு. பாலமுருகன் · The MLA |
| `balaji.html` | திரு. எஸ். பாலாஜி · Execution |
| `impact.html` | சாதனைகள் · Impact & Gallery |
| `404.html` | Served by GitHub Pages for unknown paths |

Every page links to every other page from the header and the footer site map.

## Deploy to GitHub Pages

**Option A — project site** (`https://<username>.github.io/<repo>/`)

```bash
git init
git add -A
git commit -m "Ambattur Skill Mission website"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

Then on GitHub: **Settings → Pages → Source: Deploy from a branch → Branch:
`main`, folder: `/ (root)` → Save**. The site is live in a minute or two.

**Option B — user site** (`https://<username>.github.io/`)

Name the repository exactly `<username>.github.io` and push the same way. Pages
turns on automatically.

Because every link is relative, both options work without changing any file.

### Custom domain

Add a file named `CNAME` containing just your domain (e.g. `ambatturtvk.in`),
push it, then point a `CNAME` DNS record at `<username>.github.io`. Enable
**Enforce HTTPS** in Settings → Pages once the certificate is issued.

## Before you go public

**The application form does not submit anywhere.** GitHub Pages serves static
files only — it cannot receive form data. The form on `apply.html` is a visual
mockup. To make it live, pick one:

- A **Google Form** — easiest. Create it, then replace the mockup block with the
  embed `<iframe>`, or link the Apply button straight to the form.
- **Formspree** or similar — wrap the fields in
  `<form action="https://formspree.io/f/xxxx" method="POST">` and turn each
  grey field into a real `<input name="...">`.
- A **phone number and office walk-in only** — delete the form and keep the
  eligibility, documents and help-desk sections.

**Fill in the placeholders.** Anything in `[square brackets]` is waiting for
real content — phone, email, office address, office hours, ward list, dates,
and every statistic. Search the folder for `[` to find them all.

**Two items still need a decision:**

1. The designation under the Vijay photograph on the home page.
2. The three proposed course-module lists on `skill-mission.html`, marked
   `PROPOSED`, and the framing paragraph beside the Vijay photograph, marked
   `NOT A QUOTE`. Both need approval before launch.

**Still to supply:** gallery photographs and press logos on `impact.html` — the
dashed frames show the crop each slot expects.

## Editing

Text is plain HTML; open a file and edit it. Colours, fonts and spacing come
from the CSS variables in the `<style>` block at the top of each page (`--red`,
`--gold`, `--ink`, `--paper`, and the two font stacks). `styles.css` holds only
the responsive rules — the breakpoints are 1400px (navigation collapses to a
menu button), 1240px, 900px, 640px and 400px.

The pages were generated from the design canvas in the parent folder. If you
regenerate them, your hand edits here will be overwritten — so once you start
editing this folder by hand, treat it as the source of truth.

## Images

`balamurugan.jpg`, `balaji.jpg`, `vijay.jpg`, `tvk-logo.png`. To swap a photo,
replace the file with one of similar proportions and keep the name. The emblem
was extracted from the campaign badge supplied; a clean party-logo file can
replace `tvk-logo.png` directly.
